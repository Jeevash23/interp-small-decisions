"""Portfolio tracker sederhana.

Simpan holding di data/portfolio.json: {symbol: {amount, avg_cost}}.
Hitung nilai live, P/L, dan alokasi memakai harga realtime.
"""

import json
from pathlib import Path

PATH = Path("data/portfolio.json")


def load():
    if PATH.exists():
        try:
            return json.loads(PATH.read_text())
        except Exception:
            return {}
    return {}


def save(pf):
    PATH.parent.mkdir(parents=True, exist_ok=True)
    PATH.write_text(json.dumps(pf, indent=1))


def add(symbol, amount, avg_cost=None):
    pf = load()
    sym = symbol.upper()
    entry = pf.get(sym, {"amount": 0.0, "avg_cost": None})
    entry["amount"] = float(amount)
    if avg_cost is not None:
        entry["avg_cost"] = float(avg_cost)
    pf[sym] = entry
    save(pf)
    return pf


def remove(symbol):
    pf = load()
    pf.pop(symbol.upper(), None)
    save(pf)
    return pf


def valuate(price_fn):
    """Hitung nilai portfolio. price_fn(symbol) -> harga USD atau None."""
    pf = load()
    rows = []
    total = 0.0
    total_cost = 0.0
    for sym, e in pf.items():
        amt = e.get("amount") or 0.0
        price = None
        try:
            price = price_fn(sym)
        except Exception:
            price = None
        value = amt * price if price else None
        if value:
            total += value
        cost = (e.get("avg_cost") or 0) * amt
        if e.get("avg_cost"):
            total_cost += cost
        pl = (value - cost) if (value is not None and e.get("avg_cost")) else None
        pl_pct = (pl / cost * 100) if (pl is not None and cost) else None
        rows.append({
            "symbol": sym,
            "amount": amt,
            "price": price,
            "value": value,
            "avg_cost": e.get("avg_cost"),
            "pl": pl,
            "pl_pct": pl_pct,
        })
    rows.sort(key=lambda r: r["value"] or 0, reverse=True)
    for r in rows:
        r["alloc_pct"] = (r["value"] / total * 100) if (r["value"] and total) else None
    total_pl = (total - total_cost) if total_cost else None
    total_pl_pct = (total_pl / total_cost * 100) if (total_pl is not None and total_cost) else None
    return {
        "rows": rows,
        "total": total,
        "total_cost": total_cost,
        "total_pl": total_pl,
        "total_pl_pct": total_pl_pct,
    }
