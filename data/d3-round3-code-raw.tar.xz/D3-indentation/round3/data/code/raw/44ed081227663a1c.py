import functionsData, functionsPlayer, functionsGame, random

def start():
	return """ Игровой бот, в котором смерть не прощается. Для списка команд введите /help. В чатах бот не работает. \n ❗️ Для начала игры введите /reg [Имя персонажа] ❗️"""


def help():
	return """Основные команды
❗️ /reg [Имя которое будет носить персонаж] - регистрация в игре. ❗️
/unreg - удаление аккаунта в игре.
/editname - смена имени персонажа.
/info - информация о персонаже.
/top - топ десять сильнейших игроков.
❗️ /stop - отмена некоторых команд (/editname, /tavern, /workout) ❗️


Игровые команды
/next - переход на следующую локацию.
/back - переход на предыдущую локацию.
/battle - начать охоту на противника находящегося в локации.
/tavern - переход в таверну, если она есть на локации.
/workout - прокачка персонажа, если у вас остались очки прокачки.


Дополнительные команды
/hide | /show - скрывает | раскрывает кнопки
Вводить команды помимо регистрации необязательно, т.к. у бота есть кнопки."""


def reg(_id, name):
	return functionsPlayer.set(_id, name)


def unreg(_id):
	return functionsPlayer.delete(_id)


def editname(_id, name):
	edit = functionsPlayer.edit(_id, "name", name)
	if edit == "Значение редактировано.":
		return "Имя редактировано."
	else: return edit


def info(_id):
	info = functionsPlayer.get(_id)
	mobs = ""
	if info != "Пользователя не существует.":
		info_location = functionsGame.get(info['location'])
		if info_location['tavern_status'] == 1: tavern_status = "Присутствует"
		else: tavern_status = "Отсутствует"
		for x in info_location['mobs']:
			mob = functionsGame.get(x, "dataMobs.json")
			mobs += f"{mob['name']}(Опасность: {mob['level']})\n "
		return f"""
📌{info['name']}
🛡Уровень: {info['level']} ({info['exp'][0]}/{info['exp'][1]})
✨Очки боевой славы: {info['combat_scale']}
🧘Очки прокачки: {info['scale']}
💰Баланс: {info['money']}
🩸Здоровье: {info['hp'][0]}/{info['hp'][1]}
⚔Урон: {info['damage'][0]}-{info['damage'][1]}


📌Локация: {info_location['name']}
🏚Таверна: {tavern_status}
🧟Противники: {mobs}
"""
	else: return info


def top(name_file = "dataPlayers.json"):
	counter = 0
	data = functionsData.readData(name_file)
	sort = functionsData.sortKeys("combat_scale", name_file)
	sort["sort_key"].reverse()
	text = "Лучшие игроки:\n"
	for x in sort["sort_key"]:
		counter += 1
		if counter > 10: break
		text += f"{counter}. {data[x]['name']} (Очки боевой славы: {data[x]['combat_scale']})\n"

	return text


def next(_id):
	user = functionsPlayer.get(_id)
	if str( int( user["location"] ) + 1 ) in functionsData.readData("dataLocations.json"):
		functionsPlayer.edit(_id, "location", str( int( user["location"] ) + 1 ) )
		return f"Вы прошли на локацию {functionsData.readData('dataLocations.json')[str(int(user['location']) + 1)]['name']}"
	else: return "Вы уперлись в невидимую стену"

def back(_id):
	user = functionsPlayer.get(_id)
	if int ( user["location"] ) > 0:
		functionsPlayer.edit(_id, "location", str( int( user["location"] ) - 1 ) )
		return f"Вы прошли на локацию {functionsData.readData('dataLocations.json')[str(int(user['location']) - 1)]['name']}"
	else: return "Вы уперлись в невидимую стену"


def battle(_id):
	chronic = "История боя:\n"
	player = functionsPlayer.get(_id)
	location = functionsData.readData("dataLocations.json")[player['location']]
	enemy = functionsData.readData('dataMobs.json')[random.choice(location['mobs'])]

	while True:
		if player["hp"][0] <= 0:
			functionsPlayer.edit(_id, "hp", player['hp'])
			functionsPlayer.update(_id)
			return f"Вы проиграли. Вы потеряли весь прогресс и начнете всё с самого начала.\n\n{chronic}"

		if enemy["hp"][0] <= 0:
			player['exp'][0] += enemy['exp']
			player['money'] += enemy['money']
			functionsPlayer.edit(_id, "hp", player['hp'])
			functionsPlayer.edit(_id, "exp", player['exp'])
			functionsPlayer.edit(_id, "money", player['money'])
			functionsPlayer.update(_id)
			return f"Вы одержали победу над {enemy['name']}\nВы получили {enemy['exp']} опыта и {enemy['money']} монет.\nДля восстановления здоровья сходите в таверну\n\n{chronic}"

		damage_player = random.randint(player["damage"][0], player["damage"][1])
		damage_enemy = random.randint(enemy["damage"][0], enemy["damage"][1])
		player["hp"][0] -= damage_enemy
		enemy["hp"][0] -= damage_player
		chronic += f"{player['name']}({player['hp'][0]+damage_enemy}) ударил {enemy['name']}({enemy['hp'][0]+damage_player}) с уроном {damage_player}\n{enemy['name']}({enemy['hp'][0]}) ударил {player['name']}({player['hp'][0]}) с уроном {damage_enemy}\n"

def tavern(_id, arg):
	player = functionsPlayer.get(_id)
	if arg == "Выпить до полного ХП":
		arg = player['hp'][1] - player['hp'][0]
	if player["money"] >= arg >= 0:
		functionsPlayer.edit(_id, "money", player["money"] - arg)
		if ( player["hp"][0] + arg ) > player["hp"][1]:
			functionsPlayer.edit(_id, "hp", [player["hp"][1], player["hp"][1]])
		else:
			functionsPlayer.edit(_id, "hp", [player["hp"][0] + arg, player["hp"][1]])
		functionsPlayer.update(_id)
		return f"Вы выпили {arg} литров пива и восстановили {functionsPlayer.get(_id)['hp'][0] - player['hp'][0]} очков здоровья."
	else:
		return "Не хватает денег для пива. Вас выпнули из помещения."


def workout(_id, arg):
	player = functionsPlayer.get(_id)
	if player["scale"] > 0:
		if arg == "Урон":
			functionsPlayer.edit(_id, "damage", [player["damage"][0] + 1, player["damage"][1] + 1])
			functionsPlayer.edit(_id, "scale", player["scale"] - 1)
			functionsPlayer.update(_id)
			return f"Вы успешно прокачали свой урон\nУрон: {functionsPlayer.get(_id)["damage"][0]} - {functionsPlayer.get(_id)["damage"][1]}"
		elif arg == "Здоровье":
			functionsPlayer.edit(_id, "hp", [player["hp"][0], player["hp"][1] + 5])
			functionsPlayer.edit(_id, "scale", player["scale"] - 1)
			functionsPlayer.update(_id)
			return f"Вы успешно прокачали свое здоровье\nХП: {functionsPlayer.get(_id)["hp"][0]} / {functionsPlayer.get(_id)["hp"][1]}"
		else: return "Выберите Урон или Здоровье."
	else: return "Нету очков прокачки."
	functionsPlayer.update(_id)