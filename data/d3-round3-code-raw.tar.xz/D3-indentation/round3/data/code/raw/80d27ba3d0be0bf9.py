"""两阶段管线编排：LLM 语义识别（IR）→ 确定性布局渲染（SVG + Excalidraw scene）。

架构族图型走本引擎；时序图 / ER / 泳道等由 SkipSignal 触发回退旧 HTML 管线。
"""

from __future__ import annotations

import ir
import irprompt
import layout
import llm
import render
import json


def _merge_env(base_env: dict, config) -> dict:
    """合并请求里的 config 覆盖（兼容 DIAGRAM_LLM_* 直传与常见别名）。"""
    env = dict(base_env or {})
    if not isinstance(config, dict):
        return env
    aliases = {
        "DIAGRAM_LLM_BASE_URL": ("baseUrl", "base_url", "api_base", "apiBase"),
        "DIAGRAM_LLM_API_KEY": ("apiKey", "api_key", "key"),
        "DIAGRAM_LLM_MODEL": ("model",),
    }
    nested = config.get("llm") if isinstance(config.get("llm"), dict) else {}
    source = {**config, **nested}
    for target, keys in aliases.items():
        for key in keys:
            if isinstance(source.get(key), str) and source[key].strip():
                env[target] = source[key].strip()
                break
    for key in aliases:
        if isinstance(source.get(key), str) and source[key].strip():
            env[key] = source[key].strip()
    if env.get('DIAGRAM_LLM_BASE_URL', '').rstrip('/') != (base_env or {}).get('DIAGRAM_LLM_BASE_URL', '').rstrip('/'):
        # A user-supplied endpoint must never receive the server's credential.
        env['DIAGRAM_LLM_API_KEY'] = next((source[k].strip() for k in ('DIAGRAM_LLM_API_KEY','apiKey','api_key','key')
                                         if isinstance(source.get(k),str)), '')
    return env


def generate(env: dict, user_input: str, context=None) -> dict:
    """执行两阶段生成。

    返回 {"kind": "engine", ...} 或 {"kind": "legacy", "text": <旧管线输出>}。
    """
    user_input = (user_input or "").strip()
    if context:
        if not isinstance(context, dict) or not isinstance(context.get('ir'), dict):
            raise ir.IRError('当前图缺少结构数据，请新建架构图')
        current = ir.parse_ir(json.dumps(context['ir'], ensure_ascii=False))
        if not isinstance(context.get('scene', []), list) or len(context.get('scene', [])) > 2000:
            raise ir.IRError('当前场景格式无效')
        labels = {str(e.get('containerId')): e.get('text') for e in context.get('scene', [])
                  if isinstance(e, dict) and e.get('type') == 'text' and e.get('containerId')}
        labels.update({str(e.get('id')):e.get('text') for e in context.get('scene', [])
                       if isinstance(e,dict) and e.get('type')=='text' and not e.get('containerId')})
        scene = context.get('scene', [])
        if not scene or any(isinstance(e,dict) and e.get('customData',{}).get('architectureId') for e in scene):
            visible = {e.get('id') for e in scene if isinstance(e,dict) and not e.get('isDeleted')}
            current['items'] = [item for item in current['items'] if item['id'] in visible]
            current['modules'] = [module for module in current['modules'] if module['id'] in visible]
            known = {i['id'] for i in current['items']} | {m['id'] for m in current['modules']} | {'core'}
            current['edges'] = [edge for edge in current['edges'] if edge['from'] in known and edge['to'] in known]
        for node in [current['core'], *current['modules'], *current['items']]:
            label = labels.get(node['id']) or labels.get(node['id']+'-title')
            if label:
                node['label'] = str(label).strip()[:80]
        user_input = ('请基于当前架构修改，只修改用户要求的部分，保留其余节点、关系和原始 id。'
                      '新增节点使用新 id。不要因为节点多而省略原有内容。\n当前架构：\n'
                      + json.dumps(current, ensure_ascii=False) + '\n修改要求：\n' + user_input)
    text = ""
    last_error = ""
    parsed = None
    for attempt in range(2):
        messages = irprompt.build_ir_messages(user_input,
                                              previous=text or None, error=last_error)
        text = llm.call_llm(env, messages)
        try:
            parsed = ir.parse_ir(text)
            break
        except ir.SkipSignal:
            raise
        except ir.IRError as exc:
            last_error = str(exc)
            parsed = None
    if parsed is None:
        raise ir.IRError(last_error or "IR 解析失败")

    doc = layout.build_doc(parsed)
    scene = render.excalidraw_scene(doc)
    parents = {item['id']: item.get('module') for item in parsed['items']}
    for element in scene:
        custom = element.get('customData', {})
        if custom.get('architectureId') in parents:
            custom['parentId'] = parents[custom['architectureId']]
    shown_edges = {(p.get('source'), p.get('target')) for p in doc['prims'] if p['k'] == 'edge'}
    omitted = [e for e in parsed['edges'] if e['type'] in ('flows', 'calls')
               and (e['from'], e['to']) not in shown_edges]
    notices = list(parsed.get('notices', []))
    if doc.get('relationship_overview'):
        notices.append('当前为简洁关系视图，仅展示模块间主关系；完整关系保留在结构数据中。')
    elif omitted:
        notices.append(f'布局未绘制 {len(omitted)} 条关系；结构数据仍保留这些关系。')
    return {
        "kind": "engine",
        "intent": doc["intent"],
        "summary": doc["summary"],
        "html": render.svg_html(doc),
        "scene": scene,
        "sceneJson": json.dumps(scene, ensure_ascii=False),
        "ir": parsed,
        "files": render.icon_files(doc),
        "notices": notices,
    }
