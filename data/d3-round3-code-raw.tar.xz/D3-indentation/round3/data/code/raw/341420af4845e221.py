import functionsData, buttons
from telebot import types


def buttonsPlayer(user):
	if user != "Пользователя не существует.":

		if user['check_status'] == 0:
			return buttons.user_check_status_0

		elif user['check_status'] == 1:
			return buttons.user_check_status_1

		elif user['check_status'] == 2:
			return buttons.user_check_status_2

		elif user['check_status'] == 3:
			return buttons.user_check_status_3

	else: return buttons.user_dont_reg

def set(_id, name, name_file = "dataPlayers.json"):
	data = functionsData.readData(name_file)
	if _id not in data:
		if checkName(name, data) != True:
			return checkName(name, data)
		else:
			data[_id] = {
				"name": name,
				"check_status": 0,
				"admin_status": 0,
				"location": "0",
				"level": 1,
				"scale": 0,
				"exp": [0, 10],
				"money": 0,
				"combat_scale": 0,
				"hp": [10, 10],
				"damage": [1, 5]
			}

			functionsData.writeData(data, name_file)
			update(_id)
			return "Вы зарегистрированы."
	else:
		return "Вы уже зарегистрированы."

def delete(_id, name_file = "dataPlayers.json"):
	data = functionsData.readData(name_file)
	if _id in data:
		del data[_id]
		functionsData.writeData(data, name_file)
		return "Вы удалили свой игровой аккаунт."
	else:
		return "Вы и так не зарегистрированы."

def edit(_id, key, argument, name_file = "dataPlayers.json"):
	if _id in functionsData.readData(name_file):
		if key == "name":
			if checkName(argument, functionsData.readData(name_file)) != True:
				return checkName(argument, functionsData.readData(name_file))
		functionsData.setKey(_id, key, argument, name_file)
		return "Значение редактировано."
	else:
		return "Пользователя не существует."

def get(_id, name_file = "dataPlayers.json"):
	if _id in functionsData.readData(name_file):
		return functionsData.getKey(_id, name_file)
	else:
		return "Пользователя не существует."

def checkName(name, data):
	if ( 20 < len(name) ) or ( 3 > len(name) ):
			return "Имя должно быть длиннее 3 символов и короче 20."

	for x in name:
		if x not in "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬЮБЁйцукенгшщзхъфывапролджэячсмитьюбё_":
			return "Недопустимые символы. Допускаются только:\n1. Русский алфавит\n2. Английский алфавит\n3. Числа\n4. Нижнее подчеркивание"
					
	for y in data:
		if name == data[y]["name"]:
			return "Такое имя уже есть."

	return True

def update(_id, name_file = "dataPlayers.json"):
	data = functionsData.readData(name_file)
	if _id in data:
		if data[_id]["hp"][0] <= 0:
			data[_id] = {
				"name": data[_id]["name"],
				"check_status": 0,
				"admin_status": data[_id]["admin_status"],
				"location": "0",
				"level": 1,
				"scale": 0,
				"exp": [0, 10],
				"money": 0,
				"combat_scale": 0,
				"hp": [10, 10],
				"damage": [1, 5]
			}
		if data[_id]["exp"][0] >= data[_id]["exp"][1]:
			data[_id]["exp"][0] = 0
			data[_id]["level"] += 1;	data[_id]["scale"] += 1
			if data[_id]["level"] > 10: data[_id]["exp"][1] = data[_id]["level"]*10*int(data[_id]["level"]//10 * 2)
			else: data[_id]["exp"][1] = data[_id]["level"]*10
			
		data[_id]["combat_scale"] = int(((data[_id]["hp"][1]) * 1.242541236123543212 + ((data[_id]["damage"][0] + data[_id]["damage"][1]) * 2.5) * 1.242541236123543212) // 1)
	functionsData.writeData(data, name_file)