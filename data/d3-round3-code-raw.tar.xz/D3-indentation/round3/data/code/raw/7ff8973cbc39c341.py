"""Validate the list's local links, anchors, and entry conventions."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit


ROOT = Path(__file__).resolve().parents[1]
LINK = re.compile(r"\]\(([^\s)]+)\)")
HEADING = re.compile(r"^#{1,6}\s+(.+?)\s*$", re.MULTILINE)
ENTRY = re.compile(r"^- \[([^\]]+)\]\((https?://[^\s)]+)\) - (.+)$")


def anchors(text: str) -> set[str]:
    result: set[str] = set()
    seen: Counter[str] = Counter()
    for heading in HEADING.findall(text):
        heading = re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", heading)
        slug = re.sub(r"[^\w\- ]", "", heading.lower()).replace(" ", "-")
        suffix = "" if not seen[slug] else f"-{seen[slug]}"
        result.add(slug + suffix)
        seen[slug] += 1
    return result


def main() -> int:
    errors: list[str] = []
    files = sorted(ROOT.rglob("*.md"))
    for path in files:
        text = path.read_text(encoding="utf-8")
        relative = path.relative_to(ROOT)
        if not text.endswith("\n"):
            errors.append(f"{relative}: missing final newline")
        for number, line in enumerate(text.splitlines(), 1):
            if line.rstrip() != line:
                errors.append(f"{relative}:{number}: trailing whitespace")
            if re.search(r"[\u4e00-\u9fff]", line):
                errors.append(f"{relative}:{number}: expected English-only content")
        for target in LINK.findall(text):
            parsed = urlsplit(target)
            if parsed.scheme or target.startswith("//"):
                continue
            destination = (path.parent / unquote(parsed.path)).resolve() if parsed.path else path
            if destination != ROOT and ROOT not in destination.parents:
                errors.append(f"{relative}: link escapes repository: {target}")
                continue
            if not destination.is_file():
                errors.append(f"{relative}: missing local link: {target}")
                continue
            if parsed.fragment and destination.suffix == ".md":
                if unquote(parsed.fragment) not in anchors(destination.read_text(encoding="utf-8")):
                    errors.append(f"{relative}: missing anchor: {target}")

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    entries: list[tuple[str, str]] = []
    implementations = False
    for number, line in enumerate(readme.splitlines(), 1):
        if line == "## Implementations":
            implementations = True
        match = ENTRY.match(line)
        if match:
            if not line.endswith("."):
                errors.append(f"README.md:{number}: entry must end with a period")
            if not implementations:
                entries.append((match.group(1), match.group(2)))

    for value, count in Counter(url for _, url in entries).items():
        if count > 1:
            errors.append(f"README.md: duplicate primary paper URL: {value}")
    for value, count in Counter(title.casefold() for title, _ in entries).items():
        if count > 1:
            errors.append(f"README.md: duplicate paper title: {value}")

    for required in ("LICENSE", "CONTRIBUTING.md", "docs/taxonomy.md", "docs/reading-guide.md", "docs/evaluation.md"):
        if not (ROOT / required).is_file():
            errors.append(f"Missing required file: {required}")

    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    print(f"Validated {len(files)} Markdown files and {len(entries)} unique paper entries.")
    print("Local links, anchors, English-only Markdown, and entry conventions passed.")
    print("Remote URL availability and scientific claims were not checked by this script.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
