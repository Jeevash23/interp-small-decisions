"""Realtime price aggregator lintas exchange.

Ambil harga spot terkini dari beberapa bursa publik (tanpa API key) secara
paralel, lalu bandingkan untuk mencari selisih harga (spread/arbitrage).
"""

import concurrent.futures as cf
import time

import cache
from common import http_get


def fmt_price(v):
    if v is None:
        return "n/a"
    if v >= 1000:
        return f"${v:,.2f}"
    if v >= 1:
        return f"${v:,.4f}"
    if v >= 0.0001:
        return f"${v:,.6f}"
    return f"${v:.2e}"


def _get(url):
    return http_get(url, fast=True)


def binance(base, quote="USDT"):
    sym = f"{base}{quote}".upper()
    d = _get(f"https://api.binance.com/api/v3/ticker/24hr?symbol={sym}")
    return {
        "price": float(d["lastPrice"]),
        "change_pct": float(d["priceChangePercent"]),
        "high": float(d["highPrice"]),
        "low": float(d["lowPrice"]),
        "volume": float(d["quoteVolume"]),
        "quote": quote,
    }


def okx(base, quote="USDT"):
    inst = f"{base}-{quote}".upper()
    d = _get(f"https://www.okx.com/api/v5/market/ticker?instId={inst}")["data"][0]
    last = float(d["last"])
    open24 = float(d["open24h"])
    return {
        "price": last,
        "change_pct": (last - open24) / open24 * 100 if open24 else 0.0,
        "high": float(d["high24h"]),
        "low": float(d["low24h"]),
        "volume": float(d["volCcy24h"]),
        "quote": quote,
    }


def bybit(base, quote="USDT"):
    sym = f"{base}{quote}".upper()
    d = _get(f"https://api.bybit.com/v5/market/tickers?category=spot&symbol={sym}")
    lst = d["result"]["list"]
    if not lst:
        raise ValueError("no data")
    t = lst[0]
    return {
        "price": float(t["lastPrice"]),
        "change_pct": float(t["price24hPcnt"]) * 100,
        "high": float(t["highPrice24h"]),
        "low": float(t["lowPrice24h"]),
        "volume": float(t["turnover24h"]),
        "quote": quote,
    }


def kucoin(base, quote="USDT"):
    sym = f"{base}-{quote}".upper()
    stats = _get(f"https://api.kucoin.com/api/v1/market/stats?symbol={sym}")["data"]
    if stats.get("last") is None:
        raise ValueError("no data")
    return {
        "price": float(stats["last"]),
        "change_pct": float(stats.get("changeRate") or 0) * 100,
        "high": float(stats.get("high") or 0),
        "low": float(stats.get("low") or 0),
        "volume": float(stats.get("volValue") or 0),
        "quote": quote,
    }


_KRAKEN_MAP = {"BTC": "XBT"}


def kraken(base, quote="USD"):
    kb = _KRAKEN_MAP.get(base.upper(), base.upper())
    pair = f"{kb}{quote}".upper()
    res = _get(f"https://api.kraken.com/0/public/Ticker?pair={pair}")["result"]
    key = next(iter(res))
    t = res[key]
    last = float(t["c"][0])
    open_p = float(t["o"])
    return {
        "price": last,
        "change_pct": (last - open_p) / open_p * 100 if open_p else 0.0,
        "high": float(t["h"][1]),
        "low": float(t["l"][1]),
        "volume": float(t["v"][1]) * last,
        "quote": quote,
    }


def coinbase(base, quote="USD"):
    pair = f"{base}-{quote}".upper()
    spot = _get(f"https://api.coinbase.com/v2/prices/{pair}/spot")["data"]
    return {
        "price": float(spot["amount"]),
        "change_pct": None,
        "high": None,
        "low": None,
        "volume": None,
        "quote": quote,
    }


def coingecko(base, coin_id=None):
    """Fallback harga via CoinGecko (untuk koin yang tak ada di bursa besar).

    Butuh CoinGecko id (mis. 'pepe'); kalau tidak diberikan, pakai lowercase base.
    """
    cid = coin_id or base.lower()
    d = _get(
        f"https://api.coingecko.com/api/v3/simple/price?ids={cid}"
        f"&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true"
    )
    if cid not in d:
        raise ValueError(f"koin '{cid}' tidak ada di CoinGecko")
    row = d[cid]
    return {
        "price": float(row["usd"]),
        "change_pct": row.get("usd_24h_change"),
        "high": None,
        "low": None,
        "volume": row.get("usd_24h_vol"),
        "quote": "USD",
    }


EXCHANGES = {
    "Binance": (binance, "USDT"),
    "OKX": (okx, "USDT"),
    "Bybit": (bybit, "USDT"),
    "KuCoin": (kucoin, "USDT"),
    "Kraken": (kraken, "USD"),
    "Coinbase": (coinbase, "USD"),
}


def fetch_all(base, exchanges=None, coin_id=None):
    """Ambil harga base (mis. 'BTC') dari semua exchange secara paralel.

    Bila tak satu bursa pun punya koin ini, fallback ke CoinGecko (pakai coin_id).
    """
    names = exchanges or list(EXCHANGES)
    out = {}

    def _one(name):
        fn, quote = EXCHANGES[name]
        t0 = time.time()
        data = fn(base, quote)
        data["latency_ms"] = int((time.time() - t0) * 1000)
        data["exchange"] = name
        return name, data

    with cf.ThreadPoolExecutor(max_workers=len(names)) as ex:
        futs = {ex.submit(_one, n): n for n in names}
        for fut in cf.as_completed(futs):
            name = futs[fut]
            try:
                _, data = fut.result()
                out[name] = data
            except Exception as e:
                out[name] = {"error": str(e), "exchange": name}

    # Fallback CoinGecko bila tidak ada bursa yang berhasil
    ok = [n for n, d in out.items() if "error" not in d and d.get("price")]
    if not ok:
        try:
            t0 = time.time()
            data = coingecko(base, coin_id)
            data["latency_ms"] = int((time.time() - t0) * 1000)
            data["exchange"] = "CoinGecko"
            out["CoinGecko"] = data
        except Exception as e:
            out["CoinGecko"] = {"error": str(e), "exchange": "CoinGecko"}
    return out


def cached_fetch_all(base, exchanges=None, coin_id=None):
    """fetch_all dengan cache TTL 3 detik (harga realtime tapi hemat request).

    Key memasukkan coin_id agar dua koin dengan simbol sama tidak saling
    menimpa fallback CoinGecko.
    """
    key = f"fetchall:{base}:{coin_id or ''}:{','.join(exchanges) if exchanges else 'all'}"
    return cache.cached(key, 3, lambda: fetch_all(base, exchanges, coin_id))


def cached_order_book(base, quote="USDT"):
    return cache.cached(f"book:{base}:{quote}", 3, lambda: order_book(base, quote))


def compare(results):
    """Ringkas hasil fetch_all: harga terendah, tertinggi, spread, arbitrage."""
    valid = {n: d for n, d in results.items() if "error" not in d and d.get("price")}
    if not valid:
        return None
    prices = {n: d["price"] for n, d in valid.items()}
    low_ex = min(prices, key=prices.get)
    high_ex = max(prices, key=prices.get)
    low_p, high_p = prices[low_ex], prices[high_ex]
    spread_abs = high_p - low_p
    spread_pct = (spread_abs / low_p * 100) if low_p else 0.0
    avg = sum(prices.values()) / len(prices)
    return {
        "count": len(valid),
        "cheapest": {"exchange": low_ex, "price": low_p, "quote": valid[low_ex]["quote"]},
        "priciest": {"exchange": high_ex, "price": high_p, "quote": valid[high_ex]["quote"]},
        "spread_abs": spread_abs,
        "spread_pct": spread_pct,
        "avg": avg,
        "prices": valid,
        "errors": {n: d["error"] for n, d in results.items() if "error" in d},
    }


def order_book(base, quote="USDT", limit=500):
    """Order book Binance + estimasi likuiditas & slippage untuk notional tertentu."""
    sym = f"{base}{quote}".upper()
    d = _get(f"https://api.binance.com/api/v3/depth?symbol={sym}&limit={limit}")
    bids = [(float(p), float(q)) for p, q in d["bids"]]
    asks = [(float(p), float(q)) for p, q in d["asks"]]
    best_bid = bids[0][0] if bids else None
    best_ask = asks[0][0] if asks else None
    mid = (best_bid + best_ask) / 2 if best_bid and best_ask else None
    spread = (best_ask - best_bid) if best_bid and best_ask else None
    spread_pct = (spread / mid * 100) if spread and mid else None
    bid_liq = sum(p * q for p, q in bids)
    ask_liq = sum(p * q for p, q in asks)
    return {
        "symbol": sym,
        "best_bid": best_bid,
        "best_ask": best_ask,
        "mid": mid,
        "spread": spread,
        "spread_pct": spread_pct,
        "bid_liquidity_usd": bid_liq,
        "ask_liquidity_usd": ask_liq,
        "bids": bids,
        "asks": asks,
    }


def estimate_slippage(book, usd_amount, side="buy"):
    """Estimasi harga rata-rata & slippage untuk market order sebesar usd_amount."""
    levels = book["asks"] if side == "buy" else book["bids"]
    ref = book["best_ask"] if side == "buy" else book["best_bid"]
    if not levels or not ref:
        return None
    remaining = usd_amount
    cost = 0.0
    filled_base = 0.0
    for price, qty in levels:
        level_usd = price * qty
        take_usd = min(remaining, level_usd)
        cost += take_usd
        filled_base += take_usd / price
        remaining -= take_usd
        if remaining <= 0:
            break
    if filled_base <= 0:
        return None
    avg_price = cost / filled_base
    slippage_pct = (avg_price - ref) / ref * 100 * (1 if side == "buy" else -1)
    return {
        "avg_price": avg_price,
        "ref_price": ref,
        "slippage_pct": slippage_pct,
        "filled_usd": usd_amount - max(remaining, 0),
        "insufficient": remaining > 0,
    }

