#!/usr/bin/env python3
"""Validate the public Hehe industry research Skill pack using stdlib only."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from urllib.parse import unquote


TEXT_SUFFIXES = {
    ".md", ".json", ".py", ".ps1", ".txt", ".html", ".css", ".js",
    ".mmd", ".svg", ".yml", ".yaml", ".toml",
}
FORBIDDEN_PATH_PARTS = {"_本地维护", "90_历史备份", "__pycache__"}
PRIVATE_PATTERNS = {
    "local Windows user path": re.compile(r"[A-Za-z]:\\Users\\", re.I),
    "local Git workspace path": re.compile(r"D:\\LenovoSoftstore\\", re.I),
    "private tanzi-pro capability": re.compile(r"(?<![A-Za-z0-9-])tanzi-pro(?![A-Za-z0-9-])", re.I),
    "private AgentKey capability": re.compile(r"(?<![A-Za-z0-9-])agentkey(?![A-Za-z0-9-])", re.I),
}
LINK_RE = re.compile(r"!?\[[^\]]*\]\(([^)]+)\)")
NAME_RE = re.compile(r"(?m)^name:\s*([^\s]+)\s*$")
SKILL_REF_RE = re.compile(r"(?<![A-Za-z0-9-])hehe-[a-z0-9]+(?:-[a-z0-9]+)*(?![A-Za-z0-9-])")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def check_markdown_links(skill_dir: Path, errors: list[str]) -> None:
    root = skill_dir.resolve()
    for md in skill_dir.rglob("*.md"):
        text = read_text(md)
        for raw in LINK_RE.findall(text):
            target = raw.strip().strip("<>").split(maxsplit=1)[0]
            if not target or target.startswith("#"):
                continue
            if re.match(r"^[a-z][a-z0-9+.-]*:", target, re.I):
                continue
            target = unquote(target.split("#", 1)[0])
            if not target:
                continue
            resolved = (md.parent / target).resolve()
            try:
                resolved.relative_to(root)
            except ValueError:
                errors.append(f"cross-package link: {md.relative_to(skill_dir)} -> {raw}")
                continue
            if not resolved.exists():
                errors.append(f"broken link: {md.relative_to(skill_dir)} -> {raw}")


def main() -> int:
    repo = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    manifest_path = repo / "release-manifest.json"
    errors: list[str] = []

    for required in (repo / "README.md", repo / "LICENSE", manifest_path, repo / "skills"):
        if not required.exists():
            errors.append(f"missing required path: {required.relative_to(repo)}")
    if errors:
        print("\n".join(f"ERROR: {item}" for item in errors))
        return 1

    manifest = json.loads(read_text(manifest_path))
    skills = manifest.get("skills", [])
    names = [item.get("name") for item in skills]
    name_exceptions = manifest.get("name_exceptions", [])
    if "baojie" not in name_exceptions:
        errors.append("baojie must keep its unprefixed public name")
    prefixed_exceptions = {
        name: re.compile(rf"(?<![A-Za-z0-9-]){re.escape(manifest.get('namespace', 'hehe-') + name)}(?![A-Za-z0-9-])")
        for name in name_exceptions if isinstance(name, str)
    }
    profile = manifest.get("profile", "research-bundle")
    if profile not in {"research-bundle", "standalone-delivery"}:
        errors.append(f"unknown release profile: {profile}")
    standalone = profile == "standalone-delivery"
    if not standalone and manifest.get("display_name") != "盒盒行业研究技能包":
        errors.append("release display_name is not 盒盒行业研究技能包")
    expected_count = 1 if standalone else 16
    if len(names) != expected_count or len(set(names)) != expected_count:
        errors.append(f"release manifest must contain {expected_count} unique skills, found {len(names)}")
    roles = {role: [item.get("name") for item in skills if item.get("role") == role]
             for role in ("router", "specialty", "delivery")}
    expected_roles = (0, 0, 1) if standalone else (1, 13, 2)
    if tuple(len(roles[role]) for role in roles) != expected_roles:
        errors.append(f"invalid role counts: expected router/specialty/delivery={expected_roles}")
    deliveries = {"hehe-report-writing", "hehe-report-presentation"}
    if (standalone and not set(names) <= deliveries) or (not standalone and set(roles['delivery']) != deliveries):
        errors.append("delivery Skill names do not match the release profile")
    if any(not isinstance(name, str) or not name.startswith("hehe-") for name in names):
        errors.append("every released skill name must start with hehe-")

    skills_root = repo / "skills"
    optional_external = manifest.get("optional_external_skills", {})
    if not isinstance(optional_external, dict):
        errors.append("optional_external_skills must map names to optional-use explanations")
        optional_external = {}
    for name, reason in optional_external.items():
        if not SKILL_REF_RE.fullmatch(name) or name in names or not isinstance(reason, str) or not reason.strip():
            errors.append(f"invalid optional external Skill declaration: {name}")
    for md in skills_root.rglob("*.md"):
        for reference in sorted(set(SKILL_REF_RE.findall(read_text(md))) - set(names) - set(optional_external)):
            errors.append(f"undeclared external Skill reference: {md.relative_to(repo)} -> {reference}")
    actual_dirs = sorted(p.name for p in skills_root.iterdir() if p.is_dir())
    if sorted(names) != actual_dirs:
        errors.append(f"skills directory mismatch: expected {sorted(names)}, found {actual_dirs}")

    for name in names:
        skill_dir = skills_root / name
        skill_file = skill_dir / "SKILL.md"
        if not skill_file.is_file():
            errors.append(f"missing SKILL.md: skills/{name}")
            continue
        match = NAME_RE.search(read_text(skill_file))
        actual_name = match.group(1) if match else None
        if actual_name != name:
            errors.append(f"frontmatter name mismatch: {name} -> {actual_name}")
        check_markdown_links(skill_dir, errors)

    for item in skills:
        skill_dir = skills_root / item["name"]
        required_files = item.get("required_files", [])
        if not required_files or "SKILL.md" not in required_files:
            errors.append(f"missing required_files inventory: {item['name']}")
        for relative in required_files:
            resolved = (skill_dir / relative).resolve()
            if not resolved.is_relative_to(skill_dir.resolve()) or not resolved.is_file():
                errors.append(f"missing or invalid runtime file: {item['name']}/{relative}")

    for path in repo.rglob("*"):
        rel = path.relative_to(repo)
        if any(part in FORBIDDEN_PATH_PARTS for part in rel.parts):
            errors.append(f"forbidden path: {rel}")
        if path.is_file() and (path.suffix.lower() == ".pyc" or "_CO" in path.name):
            errors.append(f"forbidden generated file: {rel}")
        if (path.is_file() and path.suffix.lower() in TEXT_SUFFIXES
                and path.resolve() not in {Path(__file__).resolve(), repo / "scripts" / "validate_release.py"}):
            text = read_text(path)
            for label, pattern in PRIVATE_PATTERNS.items():
                if pattern.search(text):
                    errors.append(f"{label}: {rel}")
            for name, pattern in prefixed_exceptions.items():
                if pattern.search(text):
                    errors.append(f"incorrectly prefixed name ({name}): {rel}")

    entry = manifest.get("entry_skill")
    if (not standalone and entry != "hehe-industry-researcher") or (standalone and entry not in names):
        errors.append(f"unexpected entry_skill: {entry}")
    router_manifest_path = skills_root / entry / "package-manifest.json"
    if not standalone and not router_manifest_path.is_file():
        errors.append("missing router package-manifest.json")
    elif not standalone:
        router_manifest = json.loads(read_text(router_manifest_path))
        required = router_manifest.get("required_specialty_skills", [])
        required_names = [item.get("name") for item in required]
        expected_specialty = roles["specialty"]
        if router_manifest.get("install_policy") != "full-bundle":
            errors.append("router install_policy must be full-bundle")
        if router_manifest.get("entry_skill") != entry:
            errors.append("router entry_skill does not use public name")
        if sorted(required_names) != sorted(expected_specialty):
            errors.append("router required_specialty_skills does not match the 13 public specialty skills")
        bundled = router_manifest.get("bundled_delivery_skills", [])
        if sorted(item.get("name", "") for item in bundled) != sorted(roles["delivery"]):
            errors.append("router bundled_delivery_skills does not match the two delivery Skills")
        for item in required + bundled:
            expected = f"skills/{item.get('name')}"
            if item.get("suite_path") != expected or not (repo / expected / "SKILL.md").is_file():
                errors.append(f"invalid bundled Skill path: {item.get('name')} -> {item.get('suite_path')}")

    for name in roles["specialty"]:
        templates = list((skills_root / name).rglob("*交付模板.md"))
        if len(templates) != 1:
            errors.append(f"{name} must contain exactly one delivery template, found {len(templates)}")
            continue
        text = read_text(templates[0])
        headings = ["## 一、交付载体", "## 二、Markdown 主报告", "## 三、其他交付物", "## 四、保存与命名", "## 五、信息缺口", "## 六、交付条件与交付前检查"]
        positions = [text.find(heading) for heading in headings]
        if -1 in positions or positions != sorted(positions):
            errors.append(f"delivery template section order invalid: {name}")
        summary = text.find("核心摘要")
        scope = text.find("研究范围", summary + 1) if summary >= 0 else -1
        if summary < 0 or scope < 0 or summary >= scope:
            errors.append(f"delivery template is not summary-first: {name}")

    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        print(f"Validation failed with {len(errors)} issue(s).")
        return 1

    print(f"Validated {len(names)} public Skills for {manifest['display_name']}.")
    print("Names, bundle contract, Skill references, links, delivery templates, and public-package hygiene passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
