"""Crucible CLI - Click command group for building adversary simulation binaries."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import click

from crucible.agent_functions import attack_mapper
from crucible.agent_functions.comparator import FORMATTERS, compare_results
from crucible.agent_functions.compiler import compile_campaign, load_campaign_yaml
from crucible.agent_functions.group_resolver import (
    list_groups,
    resolve_group_techniques,
)
from crucible.agent_functions.navigator_parser import parse_navigator_layer


def _repo_root() -> Path:
    """Return the Payload_Type/crucible/crucible/ directory (one level up from agent_functions)."""
    return Path(__file__).resolve().parent.parent


@click.group()
@click.version_option(package_name="crucible")
def main() -> None:
    """Crucible - compile Atomic Red Team tests into adversary simulation binaries."""


# ──────────────────────────────────────────────────────────────────────
# build
# ──────────────────────────────────────────────────────────────────────

@main.command()
@click.option(
    "--techniques",
    "techniques_csv",
    default=None,
    help="Comma-separated technique IDs (e.g. T1059.001,T1053.005).",
)
@click.option(
    "--campaign",
    "campaign_path",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to a campaign YAML file.",
)
@click.option(
    "--navigator",
    "navigator_path",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to an ATT&CK Navigator layer JSON.",
)
@click.option(
    "--group",
    "group_name",
    default=None,
    help="Threat group name (e.g. APT29).",
)
@click.option(
    "--atomics",
    "atomics_root",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to atomic-red-team/atomics/ (default: ./atomic-red-team/atomics).",
)
@click.option(
    "--output",
    "output_path",
    type=click.Path(path_type=Path),
    default=Path("crucible_campaign.exe"),
    show_default=True,
    help="Output executable path.",
)
@click.option("--delay", type=int, default=None, help="Override delay between techniques (seconds).")
@click.option("--dry-run", is_flag=True, default=False, help="Bake dry-run mode into the binary.")
@click.option(
    "--cleanup-mode",
    type=click.Choice(["auto", "manual", "skip"]),
    default=None,
    help="Cleanup mode.",
)
@click.option(
    "--stix",
    "stix_path",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to enterprise-attack.json (auto-detected by default).",
)
def build(
    techniques_csv: str | None,
    campaign_path: Path | None,
    navigator_path: Path | None,
    group_name: str | None,
    atomics_root: Path | None,
    output_path: Path,
    delay: int | None,
    dry_run: bool,
    cleanup_mode: str | None,
    stix_path: Path | None,
) -> None:
    """Build a campaign binary from technique IDs, a campaign file, a Navigator layer, or a threat group."""

    # Exactly one source is required.
    sources = [
        ("--techniques", techniques_csv),
        ("--campaign", campaign_path),
        ("--navigator", navigator_path),
        ("--group", group_name),
    ]
    active = [(name, val) for name, val in sources if val is not None]
    if len(active) != 1:
        raise click.UsageError(
            "Exactly one of --techniques, --campaign, --navigator, or --group is required."
        )

    source_name, source_val = active[0]

    # Default atomics root.
    if atomics_root is None:
        atomics_root = Path("atomic-red-team") / "atomics"

    # Build the campaign definition dict.
    campaign_def: dict[str, Any]

    if source_name == "--campaign":
        campaign_def = load_campaign_yaml(source_val)  # type: ignore[arg-type]
    else:
        technique_ids: list[str] = []

        if source_name == "--techniques":
            technique_ids = [t.strip() for t in source_val.split(",") if t.strip()]  # type: ignore[union-attr]
        elif source_name == "--navigator":
            technique_ids = parse_navigator_layer(source_val)  # type: ignore[arg-type]
        elif source_name == "--group":
            click.echo(f"[crucible] Resolving techniques for group: {source_val}", err=True)
            technique_ids = resolve_group_techniques(source_val)  # type: ignore[arg-type]
            click.echo(f"[crucible] Found {len(technique_ids)} techniques", err=True)

        campaign_def = {
            "name": f"Crucible Campaign",
            "techniques": technique_ids,
        }

    # Apply CLI option overrides.
    campaign_def.setdefault("options", {})
    if delay is not None:
        campaign_def["options"]["delay_between_techniques_s"] = delay
    if dry_run:
        campaign_def["options"]["dry_run"] = True
    if cleanup_mode is not None:
        campaign_def["options"]["cleanup_mode"] = cleanup_mode

    try:
        result = compile_campaign(
            campaign_def=campaign_def,
            atomics_root=atomics_root,
            output_path=output_path,
            stix_path=stix_path,
        )
        click.echo(f"[crucible] Done: {result}", err=True)
    except Exception as exc:
        click.echo(f"[crucible] ERROR: {exc}", err=True)
        sys.exit(1)


# ──────────────────────────────────────────────────────────────────────
# list-techniques
# ──────────────────────────────────────────────────────────────────────

@main.command("list-techniques")
@click.option(
    "--atomics",
    "atomics_root",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to atomic-red-team/atomics/.",
)
def list_techniques(atomics_root: Path | None) -> None:
    """List available techniques from the atomics directory."""

    if atomics_root is None:
        atomics_root = Path("atomic-red-team") / "atomics"

    if not atomics_root.is_dir():
        click.echo(f"Atomics directory not found: {atomics_root}", err=True)
        sys.exit(1)

    count = 0
    for child in sorted(atomics_root.iterdir()):
        if child.is_dir() and child.name.startswith("T"):
            yaml_file = child / f"{child.name}.yaml"
            if yaml_file.exists():
                click.echo(child.name)
                count += 1

    click.echo(f"\n{count} techniques available", err=True)


# ──────────────────────────────────────────────────────────────────────
# list-groups
# ──────────────────────────────────────────────────────────────────────

@main.command("list-groups")
@click.option(
    "--stix",
    "stix_path",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to enterprise-attack.json.",
)
def list_groups_cmd(stix_path: Path | None) -> None:
    """List available threat groups from the STIX bundle."""

    from crucible.agent_functions.group_resolver import load_stix as gr_load

    gr_load(stix_path)
    groups = list_groups()

    for g in groups:
        aliases = ", ".join(g.get("aliases", []))
        click.echo(f"{g['name']:<30} {aliases}")

    click.echo(f"\n{len(groups)} groups available", err=True)


# ──────────────────────────────────────────────────────────────────────
# validate
# ──────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("campaign_file", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--stix",
    "stix_path",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to enterprise-attack.json.",
)
def validate(campaign_file: Path, stix_path: Path | None) -> None:
    """Validate a campaign definition without building."""

    campaign_def = load_campaign_yaml(campaign_file)
    click.echo(f"Campaign: {campaign_def.get('name', 'unnamed')}")

    attack_mapper.load_stix(stix_path)

    techniques = campaign_def.get("techniques", [])
    valid = 0
    invalid = 0

    for entry in techniques:
        tid = entry if isinstance(entry, str) else entry.get("id", "")
        if attack_mapper.validate_technique_id(tid):
            click.echo(f"  ✓ {tid} - {attack_mapper.get_technique_name(tid)}")
            valid += 1
        else:
            click.echo(f"  ✗ {tid} - NOT FOUND in ATT&CK")
            invalid += 1

    click.echo(f"\n{valid} valid, {invalid} invalid technique(s)")
    if invalid:
        sys.exit(1)


# ──────────────────────────────────────────────────────────────────────
# compare
# ──────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("baseline", type=click.Path(exists=True, path_type=Path))
@click.argument("current", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output report path (default: stdout).",
)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["text", "json", "markdown"]),
    default="text",
    help="Output format.",
)
def compare(baseline: Path, current: Path, output: Path | None, fmt: str) -> None:
    """Compare two campaign execution logs to show detection delta.

    BASELINE is the earlier run's log (.summary.json or JSON Lines .json).
    CURRENT is the later run's log in the same format.

    The report highlights regressions, improvements, added/removed tests,
    and significant timing changes (>50 %).
    """
    try:
        report = compare_results(baseline, current)
    except Exception as exc:
        click.echo(f"[crucible] ERROR loading logs: {exc}", err=True)
        sys.exit(1)

    formatter = FORMATTERS[fmt]
    rendered = formatter(report)

    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered, encoding="utf-8")
        click.echo(f"[crucible] Report written to {output}", err=True)
    else:
        click.echo(rendered)


if __name__ == "__main__":
    main()
