"""Comprehensive T1 tests for the Crucible Python pipeline, C# compilation, and data files.

Run with:
    cd D:/CyberSecurity/SharedDisk/MALDEV/Mythic Development/Agents/Crucible/Payload_Type/crucible/crucible
    PYTHONPATH=D:/CyberSecurity/SharedDisk/MALDEV/Mythic Development/Agents/Crucible/Payload_Type/crucible \
        pytest tests/ -v
"""

from __future__ import annotations

import ast
import json
import subprocess
import tempfile
from pathlib import Path

import pytest

# ── Path constants ────────────────────────────────────────────────────
_BASE = Path(__file__).resolve().parent.parent          # crucible/crucible/
_ATOMICS_ROOT = _BASE / "atomic-red-team" / "atomics"
_CAMPAIGNS_DIR = _BASE / "campaigns"
_AGENT_CODE_DIR = _BASE / "agent_code"
_AGENT_PY = _AGENT_CODE_DIR / "agent.py"
_BUILDER_PY = _BASE / "agent_functions" / "builder.py"

# ── Imports from Crucible ─────────────────────────────────────────────
from crucible.agent_functions.manifest import (
    AtomicTest,
    CampaignManifest,
    CampaignOptions,
    Phase,
    Technique,
)
from crucible.agent_functions.arg_substitutor import (
    merge_args,
    resolve_defaults,
    substitute_args,
)
from crucible.agent_functions import attack_mapper
from crucible.agent_functions.group_resolver import (
    list_groups,
    resolve_group_techniques,
)
from crucible.agent_functions.navigator_parser import parse_navigator_layer
from crucible.agent_functions.atomic_parser import (
    atomic_test_to_model,
    find_atomic_dir,
    parse_atomic_yaml,
    select_tests,
)
from crucible.agent_functions.compiler import compile_campaign, load_campaign_yaml
from crucible.agent_functions.comparator import (
    compare_results,
    format_json,
    format_markdown,
    format_text,
    load_results,
    ChangeType,
)


# ======================================================================
# 1. Manifest serialization
# ======================================================================

class TestManifestSerialization:
    """Test CampaignManifest dataclass serialization."""

    def test_to_dict_json_serializable(self):
        manifest = CampaignManifest(
            name="Test Campaign",
            options=CampaignOptions(delay_between_techniques_s=10, dry_run=True),
            phases=[
                Phase(
                    phase="execution",
                    phase_order=3,
                    techniques=[
                        Technique(
                            technique_id="T1059.001",
                            technique_name="PowerShell",
                            tests=[
                                AtomicTest(
                                    test_name="Invoke-Expression",
                                    test_guid="abc-123",
                                    executor="powershell",
                                    elevation_required=False,
                                    commands=["whoami"],
                                )
                            ],
                        )
                    ],
                )
            ],
        )
        d = manifest.to_dict()

        # Must be JSON-serializable (no exception)
        serialized = json.dumps(d)
        assert isinstance(serialized, str)
        assert len(serialized) > 0

    def test_all_top_level_fields_present(self):
        manifest = CampaignManifest(name="FieldCheck")
        d = manifest.to_dict()
        for key in ("name", "campaign_id", "created", "options", "phases"):
            assert key in d, f"Missing top-level key: {key}"

    def test_nested_structure(self):
        test = AtomicTest(
            test_name="T", test_guid="g", executor="cmd",
            elevation_required=False, commands=["echo hi"],
        )
        technique = Technique(
            technique_id="T1082", technique_name="System Info Discovery",
            tests=[test],
        )
        phase = Phase(phase="discovery", phase_order=8, techniques=[technique])
        manifest = CampaignManifest(name="Nested", phases=[phase])
        d = manifest.to_dict()

        assert len(d["phases"]) == 1
        assert len(d["phases"][0]["techniques"]) == 1
        assert len(d["phases"][0]["techniques"][0]["tests"]) == 1
        assert d["phases"][0]["techniques"][0]["tests"][0]["test_name"] == "T"


# ======================================================================
# 2. Arg substitution
# ======================================================================

class TestArgSubstitution:
    """Test substitute_args, resolve_defaults, merge_args."""

    def test_substitute_known_vars(self):
        result = substitute_args("#{foo} bar #{baz}", {"foo": "hello", "baz": "world"})
        assert result == "hello bar world"

    def test_unknown_vars_left_as_is(self):
        result = substitute_args("#{unknown}", {})
        assert result == "#{unknown}"

    def test_resolve_defaults(self):
        input_args = {
            "arg1": {"description": "x", "type": "string", "default": "val1"},
        }
        defaults = resolve_defaults(input_args)
        assert defaults == {"arg1": "val1"}

    def test_merge_args(self):
        result = merge_args({"a": "1"}, {"a": "2", "b": "3"})
        assert result["a"] == "2"
        assert result["b"] == "3"
        assert result["PathToAtomicsFolder"] == r"C:\AtomicRedTeam\atomics"


# ======================================================================
# 3. STIX mapper
# ======================================================================

class TestStixMapper:
    """Test attack_mapper functions against the real STIX bundle."""

    @pytest.fixture(autouse=True, scope="class")
    def _load_stix(self):
        attack_mapper.load_stix()

    def test_load_stix_succeeds(self):
        # If we got here, load_stix() didn't raise.
        assert attack_mapper._loaded is True

    def test_validate_known_technique(self):
        assert attack_mapper.validate_technique_id("T1059.001") is True

    def test_validate_unknown_technique(self):
        assert attack_mapper.validate_technique_id("T9999.999") is False

    def test_get_technique_name(self):
        name = attack_mapper.get_technique_name("T1059.001")
        assert name == "PowerShell"

    def test_get_technique_tactics(self):
        tactics = attack_mapper.get_technique_tactics("T1059.001")
        assert "execution" in tactics

    def test_get_earliest_tactic(self):
        tactic, order = attack_mapper.get_earliest_tactic("T1059.001")
        assert tactic == "execution"
        assert order == 3

    def test_get_all_technique_ids_count(self):
        ids = attack_mapper.get_all_technique_ids()
        assert isinstance(ids, list)
        assert len(ids) > 500, f"Expected >500 technique IDs, got {len(ids)}"


# ======================================================================
# 4. Group resolver
# ======================================================================

class TestGroupResolver:
    """Test group_resolver functions against the real STIX bundle."""

    def test_resolve_apt29(self):
        techniques = resolve_group_techniques("APT29")
        assert len(techniques) > 0

    def test_all_ids_start_with_T(self):
        techniques = resolve_group_techniques("APT29")
        for tid in techniques:
            assert tid.startswith("T"), f"Expected technique ID starting with T, got {tid}"

    def test_list_groups_count(self):
        groups = list_groups()
        assert len(groups) > 100, f"Expected >100 groups, got {len(groups)}"

    def test_unknown_group_raises(self):
        with pytest.raises(KeyError):
            resolve_group_techniques("NonExistentFakeGroup12345")


# ======================================================================
# 5. Navigator parser
# ======================================================================

class TestNavigatorParser:
    """Test parse_navigator_layer with synthetic Navigator JSON."""

    def test_parse_layer(self, tmp_path):
        layer = {
            "name": "test layer",
            "techniques": [
                {"techniqueID": "T1059.001", "score": 100, "color": "#ff0000"},
                {"techniqueID": "T1082", "score": 50, "color": ""},
                {"techniqueID": "T1016", "score": 0, "color": ""},   # excluded
                {"techniqueID": "T1059.001", "score": 80, "color": ""},  # duplicate
                {"techniqueID": "T1078", "score": 0, "color": "#00ff00"},  # color set → included
            ],
        }
        layer_path = tmp_path / "test_layer.json"
        layer_path.write_text(json.dumps(layer), encoding="utf-8")

        result = parse_navigator_layer(layer_path)

        # T1059.001 (score>0), T1082 (score>0), T1078 (color set)
        assert "T1059.001" in result
        assert "T1082" in result
        assert "T1078" in result

    def test_score_zero_empty_color_excluded(self, tmp_path):
        layer = {
            "techniques": [
                {"techniqueID": "T1016", "score": 0, "color": ""},
            ],
        }
        layer_path = tmp_path / "excluded.json"
        layer_path.write_text(json.dumps(layer), encoding="utf-8")

        result = parse_navigator_layer(layer_path)
        assert "T1016" not in result

    def test_deduplication(self, tmp_path):
        layer = {
            "techniques": [
                {"techniqueID": "T1059.001", "score": 100, "color": ""},
                {"techniqueID": "T1059.001", "score": 50, "color": ""},
            ],
        }
        layer_path = tmp_path / "dedup.json"
        layer_path.write_text(json.dumps(layer), encoding="utf-8")

        result = parse_navigator_layer(layer_path)
        assert result.count("T1059.001") == 1


# ======================================================================
# 6. Atomic parser
# ======================================================================

class TestAtomicParser:
    """Test atomic_parser functions against real Atomic RT data."""

    def test_find_atomic_dir_t1082(self):
        path = find_atomic_dir(_ATOMICS_ROOT, "T1082")
        assert path.exists()
        assert path.name == "T1082.yaml"

    def test_parse_atomic_yaml(self):
        path = find_atomic_dir(_ATOMICS_ROOT, "T1082")
        data = parse_atomic_yaml(path)
        assert isinstance(data, dict)
        assert "atomic_tests" in data

    def test_select_tests_first(self):
        path = find_atomic_dir(_ATOMICS_ROOT, "T1082")
        data = parse_atomic_yaml(path)
        tests = select_tests(data, "first")
        assert len(tests) == 1

    def test_select_tests_all(self):
        path = find_atomic_dir(_ATOMICS_ROOT, "T1059.001")
        data = parse_atomic_yaml(path)
        tests = select_tests(data, "all")
        assert len(tests) > 1, f"Expected >1 Windows tests for T1059.001, got {len(tests)}"

    def test_atomic_test_to_model(self):
        path = find_atomic_dir(_ATOMICS_ROOT, "T1082")
        data = parse_atomic_yaml(path)
        raw_tests = select_tests(data, "first")
        model = atomic_test_to_model(raw_tests[0])
        assert isinstance(model, AtomicTest)
        assert model.test_name
        assert model.executor


# ======================================================================
# 7. Campaign YAML loading
# ======================================================================

class TestCampaignYamlLoading:
    """Load each campaign YAML and validate structure."""

    @pytest.fixture(autouse=True, scope="class")
    def _load_stix(self):
        attack_mapper.load_stix()

    def _campaign_files(self):
        files = sorted(_CAMPAIGNS_DIR.glob("*.yaml"))
        assert len(files) == 8, f"Expected 8 campaign files, found {len(files)}"
        return files

    def test_all_campaigns_load(self):
        for path in self._campaign_files():
            data = load_campaign_yaml(path)
            assert isinstance(data, dict), f"Failed to load {path.name}"

    def test_campaigns_have_name_and_techniques(self):
        for path in self._campaign_files():
            data = load_campaign_yaml(path)
            assert "name" in data, f"{path.name} missing 'name'"
            # Campaign must have 'techniques' or 'group'
            assert "techniques" in data or "group" in data, \
                f"{path.name} missing 'techniques' or 'group'"

    def test_technique_ids_valid(self):
        for path in self._campaign_files():
            data = load_campaign_yaml(path)
            techniques = data.get("techniques", [])
            for entry in techniques:
                tid = entry if isinstance(entry, str) else entry.get("id", "")
                if tid:
                    assert attack_mapper.validate_technique_id(tid), \
                        f"Invalid technique {tid} in {path.name}"


# ======================================================================
# 8. Compiler (manifest generation)
# ======================================================================

class TestCompiler:
    """Test compile_campaign produces a binary."""

    def test_compile_discovery_campaign(self, tmp_path):
        campaign_def = {
            "name": "T1 Discovery Test",
            "techniques": [
                {"id": "T1082"},   # System Information Discovery
                {"id": "T1016"},   # System Network Configuration Discovery
                {"id": "T1033"},   # System Owner/User Discovery
            ],
        }
        output = tmp_path / "test_campaign.exe"
        result_path = compile_campaign(
            campaign_def=campaign_def,
            atomics_root=_ATOMICS_ROOT,
            output_path=output,
        )
        assert result_path.exists(), f"Compiled output not found at {result_path}"
        size = result_path.stat().st_size
        # If dotnet is available, we get an EXE > 1MB.
        # If not, we get a JSON manifest (still valid output).
        if result_path.suffix == ".exe":
            assert size > 1_000_000, f"EXE too small: {size} bytes"
        else:
            # JSON fallback - just verify it's valid JSON.
            data = json.loads(result_path.read_text(encoding="utf-8"))
            assert "name" in data
            assert "phases" in data


# ======================================================================
# 9. Comparator
# ======================================================================

class TestComparator:
    """Test compare_results and formatters with synthetic data."""

    @pytest.fixture()
    def result_files(self, tmp_path):
        baseline = {
            "results": [
                {"technique_id": "T1082", "test_name": "SysInfo", "status": "success",
                 "test_guid": "a1", "exit_code": 0, "duration_ms": 100},
                {"technique_id": "T1016", "test_name": "NetConfig", "status": "failed",
                 "test_guid": "a2", "exit_code": 1, "duration_ms": 200},
            ]
        }
        current = {
            "results": [
                {"technique_id": "T1082", "test_name": "SysInfo", "status": "success",
                 "test_guid": "a1", "exit_code": 0, "duration_ms": 110},
                {"technique_id": "T1016", "test_name": "NetConfig", "status": "success",
                 "test_guid": "a2", "exit_code": 0, "duration_ms": 150},
                {"technique_id": "T1059.001", "test_name": "PowerShell", "status": "success",
                 "test_guid": "a3", "exit_code": 0, "duration_ms": 300},
            ]
        }
        bp = tmp_path / "baseline.json"
        cp = tmp_path / "current.json"
        bp.write_text(json.dumps(baseline), encoding="utf-8")
        cp.write_text(json.dumps(current), encoding="utf-8")
        return bp, cp

    def test_compare_results(self, result_files):
        bp, cp = result_files
        report = compare_results(bp, cp)

        deltas_by_tid = {d.technique_id: d for d in report.deltas}
        assert deltas_by_tid["T1016"].change == ChangeType.IMPROVED
        assert deltas_by_tid["T1059.001"].change == ChangeType.ADDED
        assert deltas_by_tid["T1082"].change == ChangeType.UNCHANGED

    def test_format_text(self, result_files):
        bp, cp = result_files
        report = compare_results(bp, cp)
        text = format_text(report)
        assert len(text) > 0
        assert "IMPROVED" in text or "ADDED" in text

    def test_format_json(self, result_files):
        bp, cp = result_files
        report = compare_results(bp, cp)
        j = format_json(report)
        assert len(j) > 0
        parsed = json.loads(j)
        assert "deltas" in parsed

    def test_format_markdown(self, result_files):
        bp, cp = result_files
        report = compare_results(bp, cp)
        md = format_markdown(report)
        assert len(md) > 0
        assert "| Change |" in md or "# Crucible" in md


# ======================================================================
# 10. C# build
# ======================================================================

class TestCSharpBuild:
    """Verify the C# project builds."""

    def test_dotnet_build(self):
        result = subprocess.run(
            ["dotnet", "build", str(_AGENT_CODE_DIR), "-c", "Release"],
            capture_output=True,
            text=True,
            cwd=str(_BASE),
            timeout=120,
        )
        assert result.returncode == 0, \
            f"dotnet build failed:\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"


# ======================================================================
# 11. Python agent syntax
# ======================================================================

class TestAgentSyntax:
    """Verify agent.py is syntactically valid Python."""

    def test_agent_py_parses(self):
        assert _AGENT_PY.exists(), f"agent.py not found at {_AGENT_PY}"
        source = _AGENT_PY.read_text(encoding="utf-8")
        ast.parse(source, filename=str(_AGENT_PY))


# ======================================================================
# 12. Builder syntax
# ======================================================================

class TestBuilderSyntax:
    """Verify builder.py is syntactically valid Python."""

    def test_builder_py_parses(self):
        assert _BUILDER_PY.exists(), f"builder.py not found at {_BUILDER_PY}"
        source = _BUILDER_PY.read_text(encoding="utf-8")
        ast.parse(source, filename=str(_BUILDER_PY))
