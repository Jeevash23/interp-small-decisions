"""ALTCHA v3 proof-of-work algorithm lab: solve, re-derive and falsify offline.

Implements the documented scheme read from the reference widget sources
(src/pow.ts, src/algorithms/sha.ts) with stdlib only, records a dated
artifact under data/runtime_tests/, and exits non-zero on any failure.
The artifact is public evidence for the ledger's runtime_test record.

Scheme (per fetched sources, pinned in the artifact):
  password(counter) = nonce || counter_be32            # uint32 counter mode
  derived(counter)  = SHA-256 iterated `cost` times over salt || password,
                      truncated to keyLength bytes
  solution          = smallest counter whose derived hex starts with keyPrefix
  verification      = re-derive at the submitted counter (constant-time
                      compare) and check the prefix; anything else is invalid
"""

import hashlib
import json
import platform
import secrets
import struct
import sys
import time
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [
    "https://raw.githubusercontent.com/altcha-org/altcha/HEAD/src/pow.ts",
    "https://raw.githubusercontent.com/altcha-org/altcha/HEAD/src/algorithms/sha.ts",
]
KEY_LENGTH = 32
UINT32_MAX = 0xFFFFFFFF


def derive(salt: bytes, password: bytes, cost: int, key_length: int = KEY_LENGTH) -> bytes:
    """Iterated SHA-256 over salt||password, full digest re-hashed each round."""
    digest = hashlib.sha256(salt + password).digest()
    for _ in range(cost - 1):
        digest = hashlib.sha256(digest).digest()
    return digest[:key_length]


def solve(salt: bytes, nonce: bytes, cost: int, key_prefix: str, deadline_s: float = 60.0):
    """Search the smallest counter whose derived key hex starts with key_prefix."""
    prefix = key_prefix.lower()
    started = time.monotonic()
    for counter in range(UINT32_MAX + 1):
        if counter % 4096 == 0 and time.monotonic() - started > deadline_s:
            raise TimeoutError(f"solver deadline exceeded for prefix {prefix}")
        password = nonce + struct.pack(">I", counter)
        key = derive(salt, password, cost)
        if key.hex().startswith(prefix):
            return counter, key, time.monotonic() - started
    raise ValueError("no solution within uint32 counter space")


def constant_time_equal(a: bytes, b: bytes) -> bool:
    if len(a) != len(b):
        return False
    result = 0
    for x, y in zip(a, b):
        result |= x ^ y
    return result == 0


def verify(salt: bytes, nonce: bytes, cost: int, key_prefix: str, counter: int, key: bytes) -> bool:
    """A malformed solution is an invalid solution, not an error."""
    try:
        key_hex = key.hex()
    except AttributeError:
        return False
    if not key_hex or key_hex != key_hex.lower() or len(key) != KEY_LENGTH:
        return False
    if not isinstance(counter, int) or not 0 <= counter <= UINT32_MAX:
        return False
    expected = derive(salt, nonce + struct.pack(">I", counter), cost)
    return constant_time_equal(expected, key) and expected.hex().startswith(key_prefix.lower())


def run_cases(cases):
    results = []
    for case in cases:
        salt = secrets.token_bytes(16)
        nonce = secrets.token_bytes(16)
        counter, key, elapsed = solve(salt, nonce, case["cost"], case["key_prefix"])
        checks = {
            "rederivation_matches": verify(salt, nonce, case["cost"], case["key_prefix"], counter, key),
            "wrong_counter_rejected": not verify(
                salt, nonce, case["cost"], case["key_prefix"], (counter + 1) % UINT32_MAX, key
            ),
            "tampered_key_rejected": not verify(
                salt, nonce, case["cost"], case["key_prefix"], counter, bytes([key[0] ^ 0xFF]) + key[1:]
            ),
            "prefix_holds": key.hex().startswith(case["key_prefix"].lower()),
        }
        results.append(
            {
                "salt_hex": salt.hex(),
                "nonce_hex": nonce.hex(),
                "cost": case["cost"],
                "key_prefix": case["key_prefix"],
                "solution_counter": counter,
                "derived_key_hex": key.hex(),
                "elapsed_seconds": round(elapsed, 3),
                **checks,
            }
        )
    return results


def main():
    cases = [
        {"cost": 1, "key_prefix": "0"},
        {"cost": 1, "key_prefix": "00"},
        {"cost": 1, "key_prefix": "000"},
        {"cost": 1, "key_prefix": "0000"},
        {"cost": 5, "key_prefix": "00"},
    ]
    results = run_cases(cases)
    passed = all(
        r[k] for r in results
        for k in ("rederivation_matches", "wrong_counter_rejected", "tampered_key_rejected", "prefix_holds")
    )
    artifact = {
        "schema": "awesome-antibot-re/runtime-test/1",
        "tested_at": date.today().isoformat(),
        "subject": "ALTCHA v3 proof-of-work algorithm (SHA-256 iterated derivation, keyPrefix target, uint32 counter)",
        "sources_pinned": SOURCES,
        "repository_status_evidence": "https://api.github.com/repos/altcha-org/altcha (pushed_at 2026-10-05, archived=false)",
        "environment": {
            "python": sys.version.replace("\n", " "),
            "platform": platform.platform(),
            "dependencies": "stdlib only (hashlib, secrets, struct); offline; no ALTCHA code executed",
        },
        "constants": {"key_length": KEY_LENGTH, "counter_mode": "uint32 big-endian appended to nonce"},
        "cases": results,
        "overall": "pass" if passed else "fail",
    }
    out_dir = ROOT / "data" / "runtime_tests"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{date.today().isoformat()}-altcha-pow.json"
    out.write_text(json.dumps(artifact, indent=2) + "\n", encoding="utf-8")
    for r in results:
        print(
            f"prefix={r['key_prefix']:<5} cost={r['cost']} counter={r['solution_counter']:<7}"
            f" {r['elapsed_seconds']:>7.3f}s rederive={r['rederivation_matches']}"
            f" wrong-rejected={r['wrong_counter_rejected']} tamper-rejected={r['tampered_key_rejected']}"
        )
    print(f"overall={artifact['overall']} artifact={out}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
