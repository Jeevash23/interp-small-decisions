from Scripts import resource_fetcher
from Scripts import utils
import random
import json
import re
from urllib.parse import quote


class Github:
    def __init__(self):
        self.utils = utils.Utils()
        self.fetcher = resource_fetcher.ResourceFetcher()

    def extract_payload(self, response):
        for script in re.findall(r"<script\b[^>]*>(.*?)</script\s*>", response, re.I | re.S):
            try:
                document = json.loads(script)
            except json.JSONDecodeError:
                continue
            payload = document.get("payload") if isinstance(
                document, dict) else None
            if isinstance(payload, dict):
                payload = payload.get("commitsRefRoute", payload)
            if isinstance(payload, dict) and "currentCommit" in payload:
                return payload
        return None

    def get_commits(self, owner, repo, branch="main"):
        """Read branch-head metadata without requiring API credentials or quota."""
        url = "https://github.com/{}/{}/commits/{}".format(
            quote(owner, safe=""), quote(repo, safe=""), quote(branch, safe="")
        )
        response = self.fetcher.fetch_and_parse_content(url)
        if not response:
            raise ValueError("无法从 GitHub 获取提交信息。")
        payload = self.extract_payload(response)
        current = payload.get("currentCommit") if payload else None
        sha = current.get("oid") if isinstance(current, dict) else None
        if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-fA-F]{40}", sha):
            raise ValueError(
                "无法找到仓库 {} 在分支 {} 上的提交信息。".format(repo, branch))
        return {"sha": sha.lower(), "url": url}

    def get_latest_release(self, owner, repo):
        url = "https://github.com/{}/{}/releases".format(owner, repo)
        response = self.fetcher.fetch_and_parse_content(url)

        if not response:
            raise ValueError(
                "无法从 GitHub 获取发行版信息。")

        tag_name = self._extract_tag_name(response)
        body = self._extract_body_content(response)

        release_tag_url = "https://github.com/{}/{}/releases/expanded_assets/{}".format(
            owner, repo, tag_name)
        response = self.fetcher.fetch_and_parse_content(release_tag_url)

        if not response:
            raise ValueError(
                "无法从 GitHub 获取展开后的资源信息。")

        assets = self._extract_assets(response)

        return {
            "body": body,
            "assets": assets
        }

    def _extract_tag_name(self, response):
        for line in response.splitlines():
            if "<a" in line and "href=\"" in line and "/releases/tag/" in line:
                return line.split("/releases/tag/")[1].split("\"")[0]
        return None

    def _extract_body_content(self, response):
        for line in response.splitlines():
            if "<div" in line and "body-content" in line:
                return response.split(line.split(">", 1)[0], 1)[1].split("</div>", 1)[0][1:]
        return ""

    def _extract_assets(self, response):
        assets = []

        in_li_block = False

        for line in response.splitlines():

            if "<li" in line:
                in_li_block = True
                download_link = None
                sha256 = None
                asset_id = None
            elif in_li_block and "</li" in line:
                if download_link and asset_id:
                    assets.append({
                        "product_name": self.extract_asset_name(download_link.split("/")[-1]),
                        "id": int(asset_id),
                        "url": "https://github.com" + download_link,
                        "sha256": sha256
                    })
                in_li_block = False

            if in_li_block:
                if download_link is None and "<a" in line and "href=\"" in line and "/releases/download" in line:
                    download_link = line.split("href=\"", 1)[
                        1].split("\"", 1)[0]

                    if download_link.endswith(".sha256") or not ("tlwm" in download_link or ("tlwm" not in download_link and "RESEARCH" not in download_link.upper() and "DEBUG" not in download_link.upper())):
                        in_li_block = False
                        continue

                if sha256 is None and "sha256:" in line:
                    sha256 = line.split("sha256:", 1)[1].split("<", 1)[0]

                if asset_id is None and "<relative-time" in line:
                    asset_id = self._generate_asset_id(line)

        return assets

    def _generate_asset_id(self, line):
        try:
            return "".join(char for char in line.split("datetime=\"")[-1].split("\"")[0][::-1] if char.isdigit())[:9]
        except:
            return "".join(random.choices('0123456789', k=9))

    def extract_asset_name(self, file_name):
        end_idx = len(file_name)
        if "-" in file_name:
            end_idx = min(file_name.index("-"), end_idx)
        if "_" in file_name:
            end_idx = min(file_name.index("_"), end_idx)
        if "." in file_name:
            end_idx = min(file_name.index("."), end_idx)
            if file_name[end_idx] == "." and file_name[end_idx - 1].isdigit():
                end_idx = end_idx - 1
        asset_name = file_name[:end_idx]

        if "Sniffer" in file_name:
            asset_name = file_name.split(".")[0]
        if asset_name == "IntelBluetooth":
            asset_name = "IntelBluetoothFirmware"
        if "unsupported" in file_name:
            asset_name += "-unsupported"
        elif "rtsx" in file_name:
            asset_name += "-rtsx"
        elif "itlwm" in file_name.lower():
            if "Sequoia" in file_name:
                asset_name += "24"
            elif "Tahoe" in file_name:
                asset_name += "25"
            elif "Sonoma14.4" in file_name:
                asset_name += "23.4"
            elif "Sonoma14.0" in file_name:
                asset_name += "23.0"
            elif "Ventura" in file_name:
                asset_name += "22"
            elif "Monterey" in file_name:
                asset_name += "21"
            elif "Big_Sur" in file_name:
                asset_name += "20"
            elif "Catalina" in file_name:
                asset_name += "19"
            elif "Mojave" in file_name:
                asset_name += "18"
            elif "High_Sierra" in file_name:
                asset_name += "17"

        return asset_name
